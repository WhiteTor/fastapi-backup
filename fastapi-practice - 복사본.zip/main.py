from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import mysql.connector

app = FastAPI()

# 데이터베이스 연결
cnx = mysql.connector.connect(user='root', password='391104', host='127.0.0.1', database='mybookdb')
cursor = cnx.cursor()


class Book(BaseModel):
    title: str
    author: str


@app.get("/books")
def read_books():
    query = "SELECT * FROM books"
    cursor.execute(query)
    result = cursor.fetchall()
    return result


@app.get("/books/{book_id}")
def read_book(book_id: int):
    query = f"SELECT * FROM books WHERE book_id = {book_id}"
    cursor.execute(query)
    result = cursor.fetchone()
    if result is None:
        raise HTTPException(status_code=404, detail="Book not found")
    return result


@app.post("/books")
def create_book(book: Book):
    if book.title == "" or book.author == "":
        raise HTTPException(status_code=400, detail="Title and Author cannot be empty")
    query = f"INSERT INTO books (title, author) VALUES ('{book.title}', '{book.author}')"
    cursor.execute(query)
    cnx.commit()
    return {"book_id": cursor.lastrowid, "title": book.title, "author": book.author}


@app.put("/books/{book_id}")
def update_book(book_id: int, book: Book):
    query = f"UPDATE books SET title = '{book.title}', author = '{book.author}' WHERE book_id = {book_id}"
    cursor.execute(query)
    cnx.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Book not found")
    return {"book_id": book_id, "title": book.title, "author": book.author}


@app.delete("/books/{book_id}")
def delete_book(book_id: int):
    query = f"DELETE FROM books WHERE book_id = {book_id}"
    cursor.execute(query)
    cnx.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Book not found")
    return {"book_id": book_id}
